import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../features/auth/authSlice';
import genealogyReducer from '../features/genealogy/genealogySlice';
import commissionReducer from '../features/commissions/commissionSlice';
import productReducer from '../features/products/productSlice';
import paymentReducer from '../features/payments/paymentSlice';
import walletReducer from '../features/wallet/walletSlice';
import kycReducer from '../features/kyc/kycSlice';
import rankReducer from '../features/ranks/rankSlice';
import adminReducer from '../features/admin/adminSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    genealogy: genealogyReducer,
    commissions: commissionReducer,
    products: productReducer,
    payments: paymentReducer,
    wallet: walletReducer,
    kyc: kycReducer,
    ranks: rankReducer,
    admin: adminReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false
    })
});
