import { useField } from 'formik';
import TextField from '@mui/material/TextField';

const FormikInput = ({ label, ...props }) => {
  const [field, meta] = useField(props);
  const errorText = meta.error && meta.touched ? meta.error : '';

  return (
    <TextField
      {...field}
      {...props}
      label={label}
      error={!!errorText}
      helperText={errorText}
      variant="outlined"
      fullWidth
      margin="normal"
    />
  );
};

export default FormikInput;
