const mongoose = require('mongoose');
const dotenv = require('dotenv');
const { faker } = require('@faker-js/faker');
const User = require('./models/User');
const Product = require('./models/Product');
const Rank = require('./models/Rank');

dotenv.config({ path: './.env' });

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB Connected...');
  } catch (err) {
    console.error(err.message);
    process.exit(1);
  }
};

const seedUsers = async (count = 50) => {
  await User.deleteMany();

  // Create admin
  const admin = await User.create({
    name: 'Admin User',
    email: 'admin@example.com',
    password: 'password123',
    role: 'admin',
    isVerified: true,
    walletBalance: 10000
  });

  console.log('Admin user created:', admin.email);

  // Create root user for genealogy
  const rootUser = await User.create({
    name: 'Root User',
    email: 'root@example.com',
    password: 'password123',
    isVerified: true,
    walletBalance: 5000
  });

  // Create regular users
  const users = [];
  for (let i = 0; i < count; i++) {
    const user = await User.create({
      name: faker.person.fullName(),
      email: faker.internet.email(),
      password: 'password123',
      isVerified: true,
      walletBalance: faker.number.float({ min: 0, max: 1000, precision: 0.01 }),
      genealogy: {
        parent: i === 0 ? null : users[Math.floor(i/2)]._id,
        position: i % 2 === 0 ? 'left' : 'right'
      }
    });
    users.push(user);
  }

  console.log(`${users.length} regular users created`);
};

const seedProducts = async (count = 20) => {
  await Product.deleteMany();

  const products = [];
  for (let i = 0; i < count; i++) {
    const product = await Product.create({
      name: faker.commerce.productName(),
      description: faker.commerce.productDescription(),
      price: faker.number.float({ min: 10, max: 1000, precision: 0.01 }),
      bvPoints: faker.number.int({ min: 10, max: 100 }),
      category: faker.commerce.department(),
      stock: faker.number.int({ min: 0, max: 100 })
    });
    products.push(product);
  }

  console.log(`${products.length} products created`);
};

const seedRanks = async () => {
  await Rank.deleteMany();

  const ranks = [
    { name: 'Bronze', level: 1, requirements: { directReferrals: 2, personalBV: 100, teamBV: 500 }, benefits: { commissionPercentage: 5 } },
    { name: 'Silver', level: 2, requirements: { directReferrals: 5, personalBV: 500, teamBV: 2500 }, benefits: { commissionPercentage: 7 } },
    { name: 'Gold', level: 3, requirements: { directReferrals: 10, personalBV: 1000, teamBV: 5000 }, benefits: { commissionPercentage: 10 } },
    { name: 'Platinum', level: 4, requirements: { directReferrals: 20, personalBV: 2500, teamBV: 10000 }, benefits: { commissionPercentage: 12 } },
    { name: 'Diamond', level: 5, requirements: { directReferrals: 50, personalBV: 5000, teamBV: 25000 }, benefits: { commissionPercentage: 15 } }
  ];

  await Rank.insertMany(ranks);
  console.log(`${ranks.length} ranks created`);
};

const seedDB = async () => {
  try {
    await connectDB();
    await seedUsers();
    await seedProducts();
    await seedRanks();
    console.log('Database seeding completed');
    process.exit();
  } catch (err) {
    console.error('Error seeding database:', err);
    process.exit(1);
  }
};

seedDB();
