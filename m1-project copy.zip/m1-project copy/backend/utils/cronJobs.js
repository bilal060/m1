const cron = require('node-cron');
const Commission = require('../models/Commission');
const User = require('../models/User');
const Order = require('../models/Order');
const logger = require('./logger');
const { processCommissions } = require('./commissionEngine');

// Run every day at midnight
cron.schedule('0 0 * * *', async () => {
  try {
    logger.info('Running daily commission processing job');
    
    // Process pending commissions
    const pendingCommissions = await Commission.find({ status: 'pending' });
    for (const commission of pendingCommissions) {
      const user = await User.findById(commission.user);
      if (user) {
        user.walletBalance += commission.amount;
        commission.status = 'paid';
        commission.paidAt = new Date();
        await user.save();
        await commission.save();
      }
    }
    
    logger.info(`Processed ${pendingCommissions.length} commissions`);
  } catch (err) {
    logger.error(`Commission processing error: ${err.message}`);
  }
});

// Run every hour to check for new orders to process commissions
cron.schedule('0 * * * *', async () => {
  try {
    logger.info('Checking for new orders to process commissions');
    
    const orders = await Order.find({ 
      paymentStatus: 'completed', 
      commissionProcessed: false 
    }).populate('user products.product');
    
    for (const order of orders) {
      await processCommissions(order);
      order.commissionProcessed = true;
      await order.save();
    }
    
    logger.info(`Processed commissions for ${orders.length} orders`);
  } catch (err) {
    logger.error(`Order commission processing error: ${err.message}`);
  }
});

// Run weekly to check rank advancements
cron.schedule('0 0 * * 0', async () => {
  try {
    logger.info('Running weekly rank advancement check');
    
    const users = await User.find().populate('genealogy.parent genealogy.left genealogy.right');
    const ranks = await Rank.find().sort({ level: 1 });
    
    for (const user of users) {
      const currentRank = ranks.find(r => r.name === user.rank) || ranks[0];
      const nextRank = ranks.find(r => r.level === currentRank.level + 1);
      
      if (nextRank) {
        // Check if user meets requirements for next rank
        const meetsRequirements = user.commissionEarned >= nextRank.requirements.personalBV;
        
        if (meetsRequirements) {
          user.rank = nextRank.name;
          await user.save();
          logger.info(`User ${user.email} advanced to ${nextRank.name} rank`);
        }
      }
    }
  } catch (err) {
    logger.error(`Rank advancement error: ${err.message}`);
  }
});

module.exports = cron;
