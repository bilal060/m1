import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { login, reset } from '../features/auth/authSlice';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import FormikInput from '../components/forms/FormikInput';
import Button from '../components/ui/Button';

export default function Login() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isLoading, isError, message } = useSelector((state) => state.auth);

  const initialValues = {
    email: '',
    password: ''
  };

  const validationSchema = Yup.object({
    email: Yup.string().email('Invalid email').required('Required'),
    password: Yup.string().required('Required')
  });

  const onSubmit = (values) => {
    dispatch(login(values))
      .unwrap()
      .then(() => {
        navigate('/');
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
      <div className="text-center mb-6">
        <h2 className="text-3xl font-extrabold text-gray-900">Sign in to your account</h2>
      </div>
      
      {isError && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded">
          {message}
        </div>
      )}

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ isValid, dirty }) => (
          <Form className="space-y-6">
            <FormikInput
              label="Email address"
              name="email"
              type="email"
              autoComplete="email"
              required
            />
            
            <FormikInput
              label="Password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
            />

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                  Remember me
                </label>
              </div>

              <div className="text-sm">
                <a href="#" className="font-medium text-indigo-600 hover:text-indigo-500">
                  Forgot your password?
                </a>
              </div>
            </div>

            <div>
              <Button
                type="submit"
                disabled={!dirty || !isValid || isLoading}
                loading={isLoading}
                className="w-full"
              >
                Sign in
              </Button>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}
