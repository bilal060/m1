import React from 'react';
import CircularProgress from '@mui/material/CircularProgress';

const Button = ({ children, loading, ...props }) => {
  return (
    <button
      {...props}
      className={}
    >
      {loading ? (
        <CircularProgress size={20} color="inherit" />
      ) : (
        children
      )}
    </button>
  );
};

export default Button;
