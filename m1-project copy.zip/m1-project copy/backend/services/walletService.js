const User = require('../models/User');
const Transaction = require('../models/Transaction');
const ErrorResponse = require('../utils/ErrorResponse');

// Get wallet balance
exports.getBalance = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    res.status(200).json({
      success: true,
      balance: user.walletBalance
    });
  } catch (err) {
    next(err);
  }
};

// Get transactions
exports.getTransactions = async (req, res, next) => {
  try {
    const transactions = await Transaction.find({ user: req.user.id })
      .sort('-createdAt')
      .limit(10);

    res.status(200).json({
      success: true,
      count: transactions.length,
      data: transactions
    });
  } catch (err) {
    next(err);
  }
};

// Transfer funds
exports.transferFunds = async (req, res, next) => {
  try {
    const { recipientId, amount } = req.body;

    if (req.user.id === recipientId) {
      return next(new ErrorResponse('Cannot transfer to yourself', 400));
    }

    const sender = await User.findById(req.user.id);
    const recipient = await User.findById(recipientId);

    if (!recipient) {
      return next(new ErrorResponse('Recipient not found', 404));
    }

    if (sender.walletBalance < amount) {
      return next(new ErrorResponse('Insufficient funds', 400));
    }

    // Perform transaction
    sender.walletBalance -= amount;
    recipient.walletBalance += amount;

    await sender.save();
    await recipient.save();

    // Record transaction
    await Transaction.create({
      user: req.user.id,
      amount,
      type: 'transfer',
      recipient: recipientId,
      balanceAfter: sender.walletBalance
    });

    res.status(200).json({
      success: true,
      data: { newBalance: sender.walletBalance }
    });
  } catch (err) {
    next(err);
  }
};
