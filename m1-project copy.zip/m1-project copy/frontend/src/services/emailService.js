import emailjs from '@emailjs/browser';

export const sendVerificationEmail = (email, verificationLink) => {
  const templateParams = {
    to_email: email,
    verification_link: verificationLink
  };

  return emailjs.send(
    process.env.REACT_APP_EMAILJS_SERVICE_ID,
    process.env.REACT_APP_EMAILJS_TEMPLATE_ID,
    templateParams,
    process.env.REACT_APP_EMAILJS_USER_ID
  );
};

export const sendPasswordResetEmail = (email, resetLink) => {
  const templateParams = {
    to_email: email,
    reset_link: resetLink
  };

  return emailjs.send(
    process.env.REACT_APP_EMAILJS_SERVICE_ID,
    'password_reset_template',
    templateParams,
    process.env.REACT_APP_EMAILJS_USER_ID
  );
};

export const sendCommissionNotification = (email, amount) => {
  const templateParams = {
    to_email: email,
    commission_amount: amount
  };

  return emailjs.send(
    process.env.REACT_APP_EMAILJS_SERVICE_ID,
    'commission_notification_template',
    templateParams,
    process.env.REACT_APP_EMAILJS_USER_ID
  );
};
