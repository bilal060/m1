import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { 
  getWalletBalance,
  getTransactions,
  getCommissions,
  getRankInfo
} from '../../features';
import DashboardStats from '../../components/dashboard/Stats';
import CommissionChart from '../../components/dashboard/CommissionChart';
import RecentTransactions from '../../components/dashboard/RecentTransactions';

export default function Dashboard() {
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(getWalletBalance());
    dispatch(getTransactions());
    dispatch(getCommissions());
    dispatch(getRankInfo());
  }, [dispatch]);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">Welcome back, {user?.name}</h1>
      <DashboardStats />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <CommissionChart />
        <RecentTransactions />
      </div>
    </div>
  );
}
