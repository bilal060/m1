const mongoose = require('mongoose');

const RankSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  level: {
    type: Number,
    required: true,
    unique: true
  },
  requirements: {
    directReferrals: {
      type: Number,
      default: 0
    },
    teamSize: {
      type: Number,
      default: 0
    },
    personalBV: {
      type: Number,
      default: 0
    },
    teamBV: {
      type: Number,
      default: 0
    }
  },
  benefits: {
    commissionPercentage: {
      type: Number,
      default: 0
    },
    bonus: {
      type: Number,
      default: 0
    }
  },
  isActive: {
    type: Boolean,
    default: true
  }
});

module.exports = mongoose.model('Rank', RankSchema);
