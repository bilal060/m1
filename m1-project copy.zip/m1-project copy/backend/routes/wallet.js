const express = require('express');
const router = express.Router();
const {
  getBalance,
  getTransactions,
  transferFunds
} = require('../services/walletService');
const { protect } = require('../middleware/auth');

router.route('/balance')
  .get(protect, getBalance);

router.route('/transactions')
  .get(protect, getTransactions);

router.route('/transfer')
  .post(protect, transferFunds);

module.exports = router;
