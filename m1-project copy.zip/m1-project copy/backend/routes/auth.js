const express = require('express');
const router = express.Router();
const { register, login, logout } = require('../services/authService');
const { protect } = require('../middleware/auth');

router.post('/register', register);
router.post('/login', login);
router.get('/logout', protect, logout);

module.exports = router;
