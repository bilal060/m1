import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getUsers } from '../../features/admin/adminSlice';
import AdminStats from '../../components/admin/AdminStats';
import UserTable from '../../components/admin/UserTable';

export default function AdminDashboard() {
  const dispatch = useDispatch();
  const { users, isLoading } = useSelector((state) => state.admin);

  useEffect(() => {
    dispatch(getUsers());
  }, [dispatch]);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
      <AdminStats />
      <div className="mt-8">
        <UserTable users={users} loading={isLoading} />
      </div>
    </div>
  );
}
