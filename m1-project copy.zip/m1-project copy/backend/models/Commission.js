const mongoose = require('mongoose');

const CommissionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  fromUser: {
    type: mongoose.Schema.ObjectId,
    ref: 'User'
  },
  order: {
    type: mongoose.Schema.ObjectId,
    ref: 'Order'
  },
  amount: {
    type: Number,
    required: true
  },
  level: {
    type: Number,
    required: true
  },
  type: {
    type: String,
    enum: ['direct', 'binary', 'unilevel', 'rank'],
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'paid'],
    default: 'pending'
  },
  paidAt: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Commission', CommissionSchema);
